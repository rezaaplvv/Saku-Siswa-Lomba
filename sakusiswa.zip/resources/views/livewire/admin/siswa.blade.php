<div class="-mx-4 -mt-4 sm:-mx-6 sm:-mt-6 md:-mx-8 md:-mt-8 p-4 sm:p-6 md:p-8 min-h-screen bg-[#ffd554] pb-24 space-y-5.5 font-sans relative overflow-hidden" x-data="{ 
    openForm: @entangle('isFormOpen'),
    confirmOpen: false,
    confirmTitle: '',
    confirmMessage: '',
    confirmAction: null,
    confirmButtonText: 'Hapus',
    confirmButtonClass: 'bg-rose-500 hover:bg-rose-600 text-white',
    
    formattedBalance: '',
    formattedSavingTarget: '',
    
    init() {
        this.formattedBalance = this.formatNumber($wire.get('balance'));
        this.formattedSavingTarget = this.formatNumber($wire.get('saving_target'));
        
        this.$watch('openForm', value => {
            if (value) {
                this.formattedBalance = this.formatNumber($wire.get('balance'));
                this.formattedSavingTarget = this.formatNumber($wire.get('saving_target'));
            }
        });
        
        this.$watch('$wire.balance', value => {
            this.formattedBalance = this.formatNumber(value);
        });
        
        this.$watch('$wire.saving_target', value => {
            this.formattedSavingTarget = this.formatNumber(value);
        });
    },
    
    formatNumber(val) {
        if (val === undefined || val === null || val === '') return '';
        let clean = val.toString().replace(/\D/g, '');
        return clean.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    },
    
    updateBalance(val) {
        let clean = val.replace(/\D/g, '');
        this.formattedBalance = this.formatNumber(clean);
        $wire.set('balance', parseFloat(clean) || 0);
    },
    
    updateSavingTarget(val) {
        let clean = val.replace(/\D/g, '');
        this.formattedSavingTarget = this.formatNumber(clean);
        $wire.set('saving_target', parseFloat(clean) || 0);
    },
    
    triggerConfirm(title, message, action, buttonText = 'Hapus', buttonClass = 'bg-rose-500 hover:bg-rose-600 text-white') {
        this.confirmTitle = title;
        this.confirmMessage = message;
        this.confirmAction = action;
        this.confirmButtonText = buttonText;
        this.confirmButtonClass = buttonClass;
        this.confirmOpen = true;
    },
    executeConfirm() {
        if (this.confirmAction) {
            this.confirmAction();
        }
        this.confirmOpen = false;
    }
}">
    
    <!-- Decorative background elements -->
    <div class="absolute top-0 right-0 w-32 h-32 opacity-10 pointer-events-none translate-x-6 -translate-y-6 z-0">
        <svg class="w-full h-full text-amber-800" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17 2c-3.87 0-7 3.13-7 7 0 2.21 1.02 4.18 2.62 5.5L12 15c-.41.34-1.07.34-1.48 0L2.3 8.3c-.63-.5-1.52-.38-2 .25-.5.63-.38 1.52.25 2l8.22 6.7c1.39 1.13 3.47 1.13 4.86 0L22 10.3c.63-.5.75-1.39.25-2-.5-.63-1.39-.75-2-.25l-2.62 2.15C17.98 9.38 17 7.41 17 5V2z"/>
        </svg>
    </div>

    <!-- Header -->
    <div class="relative z-10 flex items-center justify-between font-['Outfit'] pt-4 pb-2">
        <div class="text-left space-y-1.5">
            <h1 class="text-2xl md:text-3xl font-black text-[#0f172a] tracking-tight">Manajemen Siswa</h1>
            <p class="text-xs md:text-sm text-slate-700 font-semibold">Kelola data siswa, target tabungan, dan bantuan kredensial orang tua</p>
        </div>
        
        <div class="flex items-center space-x-2">
            <!-- Kelola Kelas Button -->
            <button 
                @click="$wire.openClassroomModal()"
                class="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-2xl flex items-center space-x-1.5 text-xs transition-all active:scale-[0.98] cursor-pointer shadow-3xs"
            >
                <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                <span>Kelas</span>
            </button>

            <!-- Tambah Siswa Button -->
            <button 
                @click="$wire.openForm()"
                class="px-4 py-2.5 bg-[#0c1a30] hover:bg-slate-800 text-white font-extrabold rounded-2xl flex items-center space-x-1.5 text-xs transition-all active:scale-[0.98] cursor-pointer shadow-xs"
            >
                <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                <span class="hidden sm:inline">Tambah Siswa</span>
                <span class="inline sm:hidden">Siswa</span>
            </button>
        </div>
    </div>

    @if(session()->has('success'))
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 px-6 py-4 rounded-2xl text-sm font-semibold relative z-10 text-left">
            {{ session('success') }}
        </div>
    @endif

    <!-- Controls Area -->
    <div class="flex flex-row gap-2 sm:gap-3 w-full relative z-20 font-['Outfit']">
        <!-- Search bar -->
        <div class="relative flex-1">
            <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-slate-400">
                <svg class="w-4.5 h-4.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </span>
            <input 
                type="text" 
                wire:model.live="search"
                class="w-full pl-11 pr-4 py-3 bg-white border border-slate-100 rounded-2xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 shadow-3xs placeholder-slate-400"
                placeholder="Cari nama siswa atau NISN..."
            >
        </div>

        <!-- Class filter dropdown (Custom Dropdown to prevent mobile overflow) -->
        <div class="relative shrink-0 w-32 sm:w-48 font-['Outfit']" x-data="{ openClass: false }">
            <button 
                @click="openClass = !openClass"
                class="w-full px-3 py-3 bg-white border border-slate-100 rounded-2xl flex items-center justify-between space-x-1.5 text-xs font-bold text-slate-700 shadow-3xs cursor-pointer transition-all active:scale-[0.97]"
            >
                <span class="truncate">{{ $classFilter === '' ? 'Semua Kelas' : 'Kelas ' . $classFilter }}</span>
                <svg class="w-3.5 h-3.5 text-slate-400 transition-transform duration-200" :class="openClass ? 'rotate-180' : ''" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                </svg>
            </button>
            <div 
                x-show="openClass" 
                @click.away="openClass = false"
                x-transition
                class="absolute right-0 mt-1.5 w-36 sm:w-48 max-h-48 overflow-y-auto rounded-2xl bg-white shadow-lg border border-slate-100 z-50 py-1"
                style="display: none; scrollbar-width: thin;"
            >
                <button wire:click="$set('classFilter', '')" @click="openClass = false" class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs {{ $classFilter === '' ? 'bg-amber-50 text-amber-900 font-bold' : '' }} cursor-pointer">Semua Kelas</button>
                @foreach($availableClasses as $cls)
                    <button wire:click="$set('classFilter', '{{ $cls }}')" @click="openClass = false" class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs {{ $classFilter === $cls ? 'bg-amber-50 text-amber-900 font-bold' : '' }} cursor-pointer">Kelas {{ $cls }}</button>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Table Section -->
    <div class="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs relative z-10 space-y-5">
        <div class="overflow-x-auto -mx-6">
            <div class="inline-block min-w-full align-middle px-6">
                <table class="min-w-full divide-y divide-slate-100 text-left">
                    <thead>
                        <tr class="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                            <th class="py-3.5 pr-4">Siswa</th>
                            <th class="py-3.5 px-4">NISN</th>
                            <th class="py-3.5 px-4">Kelas</th>
                            <th class="py-3.5 px-4">Saldo</th>
                            <th class="py-3.5 px-4">Target Tabungan</th>
                            <th class="py-3.5 pl-4 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-xs text-slate-700 font-medium">
                        @forelse($students as $student)
                            <tr wire:key="student-{{ $student->id }}" class="hover:bg-slate-50/55 transition-colors">
                                <td class="py-4 pr-4 font-bold text-slate-800">
                                    {{ $student->name }}
                                </td>
                                <td class="py-4 px-4 font-semibold text-slate-500">
                                    {{ $student->nisn }}
                                </td>
                                <td class="py-4 px-4">
                                    <span class="inline-flex items-center px-2 py-0.5 bg-slate-50 border border-slate-100 rounded-md text-[10px] font-bold text-slate-650 whitespace-nowrap">
                                        {{ $student->class_name }}
                                    </span>
                                </td>
                                <td class="py-4 px-4 font-black text-emerald-600">
                                    Rp {{ number_format($student->balance, 0, ',', '.') }}
                                </td>
                                <td class="py-4 px-4 font-bold text-slate-700">
                                    Rp {{ number_format($student->saving_target, 0, ',', '.') }}
                                </td>
                                <td class="py-4 pl-4 text-right space-x-1 shrink-0">
                                    <!-- Credentials Dropdown -->
                                    <div x-data="{ openCreds: false }" class="relative inline-block text-left">
                                        <button 
                                            @click="openCreds = !openCreds" 
                                            class="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-extrabold rounded-lg text-[10px] inline-flex items-center space-x-1 transition-all cursor-pointer border border-amber-250/20"
                                        >
                                            <span>Kredensial</span>
                                            <svg class="w-3 h-3 text-amber-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                                            </svg>
                                        </button>
                                        <div 
                                            x-show="openCreds" 
                                            @click.away="openCreds = false"
                                            x-transition
                                            class="absolute right-0 mt-1.5 w-40 rounded-xl bg-white shadow-lg border border-slate-100 z-30 py-1 overflow-hidden text-left" 
                                            style="display: none;"
                                        >
                                            <button 
                                                type="button"
                                                @click="
                                                    openCreds = false;
                                                    triggerConfirm(
                                                        'Reset Password', 
                                                        'Apakah Anda yakin ingin mereset password orang tua siswa <strong>{{ addslashes($student->name) }}</strong> kembali ke NISN default?', 
                                                        () => $wire.resetPasswordOrangTua({{ $student->id }}),
                                                        'Reset',
                                                        'bg-amber-400 hover:bg-amber-500 text-slate-900'
                                                    )
                                                "
                                                class="w-full text-left px-4 py-2.5 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer block border-b border-slate-50"
                                            >
                                                Reset Password
                                            </button>
                                            <button 
                                                type="button"
                                                @click="
                                                    openCreds = false;
                                                    triggerConfirm(
                                                        'Reset PIN Transaksi', 
                                                        'Apakah Anda yakin ingin mereset PIN transaksi orang tua siswa <strong>{{ addslashes($student->name) }}</strong>?', 
                                                        () => $wire.resetPinOrangTua({{ $student->id }}),
                                                        'Reset',
                                                        'bg-amber-400 hover:bg-amber-500 text-slate-900'
                                                    )
                                                "
                                                class="w-full text-left px-4 py-2.5 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer block"
                                            >
                                                Reset PIN
                                            </button>
                                        </div>
                                    </div>

                                    <button 
                                        type="button"
                                        @click="$wire.openForm({{ $student->id }})"
                                        class="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-[10px] transition-all cursor-pointer inline-block"
                                    >
                                        Edit
                                    </button>
                                    <button 
                                        type="button"
                                        @click="triggerConfirm(
                                            'Hapus Siswa', 
                                            'Apakah Anda yakin ingin menghapus data siswa <strong>{{ addslashes($student->name) }}</strong> secara permanen? <strong class=\'text-rose-600\'>Seluruh riwayat transaksi keuangan (setoran & penarikan) siswa ini akan terhapus secara permanen dari sistem pembukuan!</strong>', 
                                            () => $wire.deleteStudent({{ $student->id }}),
                                            'Hapus',
                                            'bg-rose-500 hover:bg-rose-600 text-white'
                                        )"
                                        class="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold rounded-lg text-[10px] transition-all cursor-pointer inline-block"
                                    >
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="py-8 text-center text-slate-400 font-semibold italic">
                                    Belum ada data siswa terdaftar.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Pagination Controls -->
        @if($students->hasPages())
            <div class="mt-5 flex items-center justify-between font-['Outfit'] text-xs font-semibold px-2 border-t border-slate-50 pt-4">
                <button 
                    wire:click="previousPage" 
                    @if($students->onFirstPage()) disabled @endif
                    class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95 shadow-3xs"
                >
                    Sebelumnya
                </button>
                
                <span class="text-slate-500 font-bold">
                    Halaman {{ $students->currentPage() }} dari {{ $students->lastPage() }}
                </span>
                
                <button 
                    wire:click="nextPage" 
                    @if(!$students->hasMorePages()) disabled @endif
                    class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95 shadow-3xs"
                >
                    Selanjutnya
                </button>
            </div>
        @endif
    </div>

    <!-- Modal Form (Alpine controlled with wire:model bindings) -->
    <div 
        x-show="openForm" 
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-sans"
        x-transition
        style="display: none;"
    >
        <div 
            @click.away="$wire.closeForm()" 
            class="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-100 relative font-['Outfit'] space-y-5"
        >
            <!-- Modal Header -->
            <div class="text-left space-y-1">
                <h3 class="text-lg font-black text-slate-800">{{ $studentId ? 'Edit Data Siswa' : 'Tambah Siswa Baru' }}</h3>
                <p class="text-xs text-slate-400 font-medium">Lengkapi rincian data diri dan target tabungan siswa</p>
            </div>

            <!-- Form -->
            <form wire:submit.prevent="saveStudent" class="space-y-4 text-left font-['Plus_Jakarta_Sans']">
                <!-- NISN -->
                <div class="space-y-1.5">
                    <label for="nisn" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">NISN (10 Digit)</label>
                    <input 
                        type="text" 
                        id="nisn" 
                        wire:model="nisn"
                        class="w-full px-4 py-3 rounded-2xl border border-slate-250 text-xs placeholder-slate-450 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40"
                        placeholder="Contoh: 0123456789"
                        required
                    >
                    @error('nisn') <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> @enderror
                </div>

                <!-- Name -->
                <div class="space-y-1.5">
                    <label for="name" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Nama Lengkap Siswa</label>
                    <input 
                        type="text" 
                        id="name" 
                        wire:model="name"
                        class="w-full px-4 py-3 rounded-2xl border border-slate-250 text-xs placeholder-slate-450 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40"
                        placeholder="Nama Lengkap Siswa"
                        required
                    >
                    @error('name') <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> @enderror
                </div>

                <!-- Class -->
                <div class="space-y-1.5" x-data="{ 
                    openSelect: false,
                    value: @entangle('class_name'),
                    options: @js($availableClasses),
                    selectOption(val) {
                        this.value = val;
                        this.openSelect = false;
                    }
                }">
                    <label class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Kelas</label>
                    <div class="relative">
                        <button 
                            type="button"
                            @click="openSelect = !openSelect"
                            class="w-full px-4 py-3 rounded-2xl border border-slate-250 text-xs font-semibold focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40 transition-all duration-200 text-left flex items-center justify-between cursor-pointer"
                        >
                            <span x-text="value ? 'Kelas ' + value : 'Pilih Kelas'" class="text-slate-800"></span>
                            <svg class="w-3.5 h-3.5 text-slate-450 transition-transform duration-200" :class="openSelect ? 'rotate-180' : ''" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                            </svg>
                        </button>

                        <div 
                            x-show="openSelect" 
                            @click.away="openSelect = false"
                            x-transition
                            class="absolute left-0 right-0 mt-1.5 max-h-48 overflow-y-auto rounded-2xl bg-white shadow-xl border border-slate-150 z-50 py-1"
                            style="display: none; scrollbar-width: thin;"
                        >
                            <button type="button" @click="selectOption('')" class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-550 text-xs cursor-pointer">Pilih Kelas</button>
                            <template x-for="cls in options" :key="cls">
                                <button 
                                    type="button" 
                                    @click="selectOption(cls)" 
                                    class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs flex items-center justify-between cursor-pointer"
                                    :class="value === cls ? 'bg-amber-50 text-amber-900 font-bold' : ''"
                                >
                                    <span x-text="'Kelas ' + cls"></span>
                                    <svg x-show="value === cls" class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                    </svg>
                                </button>
                            </template>
                        </div>
                    </div>
                    @error('class_name') <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> @enderror
                </div>

                <!-- Balance -->
                <div class="space-y-1.5">
                    <label for="balance" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Saldo Tabungan Awal (Rp)</label>
                    <input 
                        type="text" 
                        id="balance" 
                        x-model="formattedBalance"
                        @input="updateBalance($event.target.value)"
                        class="w-full px-4 py-3 rounded-2xl border border-slate-250 text-xs placeholder-slate-450 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40 disabled:opacity-60 disabled:cursor-not-allowed font-bold"
                        placeholder="0"
                        required
                        @if($studentId) disabled @endif
                    >
                    @error('balance') <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> @enderror
                </div>
 
                <!-- Saving Target -->
                <div class="space-y-1.5">
                    <label for="saving_target" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Target Tabungan (Rp)</label>
                    <input 
                        type="text" 
                        id="saving_target" 
                        x-model="formattedSavingTarget"
                        @input="updateSavingTarget($event.target.value)"
                        class="w-full px-4 py-3 rounded-2xl border border-slate-250 text-xs placeholder-slate-450 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40 font-bold"
                        placeholder="500.000"
                        required
                    >
                    @error('saving_target') <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> @enderror
                </div>

                <!-- Action buttons -->
                <div class="flex items-center space-x-3 pt-3">
                    <button 
                        type="button" 
                        @click="$wire.closeForm()"
                        class="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-2xl text-xs transition-all active:scale-[0.98] cursor-pointer"
                    >
                        Batal
                    </button>
                    <button 
                        type="submit"
                        class="flex-1 py-3 bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold rounded-2xl text-xs transition-all active:scale-[0.98] cursor-pointer shadow-xs"
                    >
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Classroom Manager Modal -->
    <div 
        x-show="$wire.isClassroomModalOpen" 
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-sans"
        x-transition
        style="display: none;"
    >
        <div 
            @click.away="$wire.closeClassroomModal()" 
            class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 relative font-['Outfit'] space-y-4 text-left"
        >
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-base font-black text-slate-800">Kelola Daftar Kelas</h3>
                <button @click="$wire.closeClassroomModal()" class="text-slate-400 hover:text-slate-650 cursor-pointer">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <!-- Flash alerts inside classroom modal -->
            @if(session()->has('class_success'))
                <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-xl text-xs font-bold animate-fadeIn">
                    {{ session('class_success') }}
                </div>
            @endif
            @if(session()->has('class_error'))
                <div class="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-2.5 rounded-xl text-xs font-bold animate-fadeIn">
                    {{ session('class_error') }}
                </div>
            @endif

            <!-- Add class form -->
            <form wire:submit.prevent="addClassroom" class="flex gap-2">
                <div class="relative flex-1">
                    <input 
                        type="text" 
                        wire:model="newClassroomName"
                        placeholder="Ketik kelas baru (misal: 1-C)"
                        class="w-full px-4 py-2.5 border border-slate-200 rounded-2xl text-xs font-bold placeholder-slate-400 focus:outline-hidden focus:border-amber-500"
                        required
                    >
                </div>
                <button 
                    type="submit" 
                    class="px-4 py-2.5 bg-[#0c1a30] hover:bg-slate-800 text-white font-extrabold rounded-2xl text-xs transition-colors cursor-pointer active:scale-95"
                >
                    Tambah
                </button>
            </form>
            @error('newClassroomName') 
                <span class="text-[10px] text-rose-500 font-bold block mt-1">{{ $message }}</span> 
            @enderror

            <!-- Classrooms list -->
            <div class="space-y-2">
                <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Daftar Kelas Resmi</div>
                <div class="max-h-48 overflow-y-auto space-y-1.5 pr-1" style="scrollbar-width: thin;">
                    @forelse($classrooms as $cls)
                        <div class="bg-slate-50 border border-slate-100 rounded-2xl px-4 py-2.5 flex items-center justify-between shadow-3xs">
                            <span class="text-xs font-bold text-slate-800">Kelas {{ $cls->name }}</span>
                            <button 
                                type="button"
                                wire:click="deleteClassroom({{ $cls->id }})"
                                class="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                                title="Hapus Kelas"
                            >
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                                </svg>
                            </button>
                        </div>
                    @empty
                        <div class="text-xs text-slate-400 italic text-center py-4">Belum ada kelas terdaftar.</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    <!-- Custom Confirmation Modal (Alpine.js controlled) -->
    <div 
        x-show="confirmOpen" 
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-sans"
        x-transition
        style="display: none;"
    >
        <div 
            @click.away="confirmOpen = false" 
            class="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100 relative font-['Outfit'] space-y-4 text-center"
        >
            <!-- Warning / Alert Icon -->
            <div class="mx-auto w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>

            <!-- Content -->
            <div class="space-y-2">
                <h3 class="text-base font-black text-slate-800" x-text="confirmTitle">Konfirmasi</h3>
                <p class="text-xs text-slate-500 font-semibold leading-relaxed" x-html="confirmMessage"></p>
            </div>

            <!-- Actions -->
            <div class="flex items-center space-x-3 pt-2">
                <button 
                    type="button" 
                    @click="confirmOpen = false"
                    class="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-2xl text-xs transition-all active:scale-[0.98] cursor-pointer"
                >
                    Batal
                </button>
                <button 
                    type="button"
                    @click="executeConfirm()"
                    class="flex-1 py-3 font-extrabold rounded-2xl text-xs transition-all active:scale-[0.98] cursor-pointer shadow-xs"
                    :class="confirmButtonClass"
                    x-text="confirmButtonText"
                >
                </button>
            </div>
        </div>
    </div>
</div>
