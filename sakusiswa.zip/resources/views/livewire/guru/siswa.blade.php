<div 
    x-data="{ 
        openDeposit: false, 
        selectedId: null, 
        selectedName: '',
        depositAmount: '',
        formattedAmount: '',
        
        updateAmount(val) {
            let clean = val.replace(/\D/g, '');
            this.depositAmount = clean;
            this.formattedAmount = clean.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }
    }"
    class="-mx-4 -mt-4 sm:-mx-6 sm:-mt-6 md:-mx-8 md:-mt-8 p-4 sm:p-6 md:p-8 min-h-screen bg-[#ffd554] pb-6 space-y-6 font-sans relative overflow-hidden"
>
    
    <!-- Leaf Decoration (Top Right background - Soft amber outline) -->
    <div class="absolute top-0 right-0 w-32 h-32 opacity-10 pointer-events-none translate-x-6 -translate-y-6 z-0">
        <svg class="w-full h-full text-amber-800" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17 2c-3.87 0-7 3.13-7 7 0 2.21 1.02 4.18 2.62 5.5L12 15c-.41.34-1.07.34-1.48 0L2.3 8.3c-.63-.5-1.52-.38-2 .25-.5.63-.38 1.52.25 2l8.22 6.7c1.39 1.13 3.47 1.13 4.86 0L22 10.3c.63-.5.75-1.39.25-2-.5-.63-1.39-.75-2-.25l-2.62 2.15C17.98 9.38 17 7.41 17 5V2z"/>
        </svg>
    </div>

    <!-- Header Welcome/Banner Card -->
    <div class="relative overflow-hidden bg-white/70 border border-slate-100 rounded-3xl p-6 shadow-xs flex items-center justify-between min-h-[160px] relative z-10 font-['Outfit']">
        <!-- Info Left Section -->
        <div class="text-left space-y-3.5 relative z-10 pr-24 md:pr-48">
            <div class="space-y-1">
                <div class="flex items-center space-x-2">
                    <h1 class="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">Kelola Siswa</h1>
                    <!-- Hand illustration using premium SVG path -->
                    <svg class="w-7 h-7 text-amber-500 shrink-0" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2a1 1 0 0 1 1 1v3.086l2.121-2.12a1 1 0 1 1 1.415 1.414L14.414 7.5l2.122 2.121a1 1 0 1 1-1.415 1.415L13 8.914V12a1 1 0 1 1-2 0V8.914l-2.121 2.121a1 1 0 1 1-1.415-1.415L9.586 7.5 7.464 5.38a1 1 0 1 1 1.415-1.414L11 6.086V3a1 1 0 0 1 1-1z" />
                    </svg>
                </div>
                <p class="text-xs md:text-sm text-slate-600 font-medium leading-relaxed">Kelola tabungan siswa kelas Anda dengan mudah</p>
            </div>
            
            @if($className)
                <!-- Pill Badge: KELAS AKTIF | 1-A -->
                <div class="inline-flex items-center space-x-2.5 px-4 py-2 bg-amber-100/60 border border-amber-200/50 rounded-full text-xs font-bold">
                    <span class="text-amber-800 uppercase tracking-wider">Kelas Aktif</span>
                    <span class="text-slate-400">|</span>
                    <span class="text-slate-900">{{ $className }}</span>
                </div>
            @endif
        </div>

        <!-- Header Illustration on the right -->
        <div class="absolute -right-4 -bottom-4 w-52 h-40 md:w-72 md:h-48 pointer-events-none z-0">
            <img src="/assets/headerguru.png" alt="Header Illustration" class="w-full h-full object-contain object-right-bottom">
        </div>
    </div>

    @if(!$className)
        <div class="bg-rose-50 border border-rose-200 text-rose-800 px-6 py-4 rounded-2xl text-sm font-medium relative z-10">
            Akun Anda belum dikaitkan dengan kelas manapun. Silakan hubungi Administrator Sekolah untuk mengkonfigurasi wali kelas.
        </div>
    @else
        <!-- Floating Success Toast / Pop-up -->
        @if(session()->has('success'))
            <div 
                x-data="{ show: true }" 
                x-show="show"
                x-init="setTimeout(() => show = false, 4000)"
                x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 scale-90 translate-y-4"
                x-transition:enter-end="opacity-100 scale-100 translate-y-0"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 scale-100 translate-y-0"
                x-transition:leave-end="opacity-0 scale-90 translate-y-4"
                class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs font-sans"
            >
                <div class="bg-white rounded-3xl p-6 max-w-xs w-full shadow-2xl border border-slate-100 text-center font-['Outfit'] space-y-4 relative animate-scaleIn">
                    <!-- Circular Checkmark Icon -->
                    <div class="w-16 h-16 rounded-full bg-emerald-50 border-4 border-emerald-100 flex items-center justify-center text-emerald-600 mx-auto animate-bounce">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                        </svg>
                    </div>
                    
                    <!-- Success Text -->
                    <div class="space-y-1.5">
                        <h3 class="text-sm font-black text-slate-800">Berhasil!</h3>
                        <p class="text-xs text-slate-500 font-semibold leading-relaxed">
                            {{ session('success') }}
                        </p>
                    </div>
                    
                    <!-- Dismiss button -->
                    <button 
                        @click="show = false" 
                        class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs transition-all active:scale-[0.98] cursor-pointer"
                    >
                        Tutup
                    </button>
                </div>
            </div>
        @endif

        @if(session()->has('error'))
            <div class="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3.5 rounded-xl text-xs font-bold relative z-10">
                {{ session('error') }}
            </div>
        @endif

        <!-- Search & Filter Area (Floating directly on the yellow background) -->
        <div class="space-y-3.5 relative z-20 font-['Outfit']">
            <!-- Row 1: Full-width Search Input Field -->
            <div class="relative w-full">
                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.602 10.602z" />
                    </svg>
                </span>
                <input 
                    type="text" 
                    wire:model.live.debounce.300ms="search" 
                    class="w-full pl-9.5 pr-4 py-2.5 border border-slate-300/40 rounded-xl text-xs placeholder-slate-505 focus:outline-hidden focus:border-slate-800 focus:ring-4 focus:ring-slate-800/10 bg-white shadow-xs"
                    placeholder="Cari nama atau NISN..."
                >
            </div>

            <!-- Row 2: Filter Button (Left) & Total Student Count (Right) -->
            <div class="flex items-center justify-between w-full">
                <!-- Filter Popover Trigger Button (Left side) -->
                <div x-data="{ openFilter: false }" class="relative">
                    <button 
                        @click="openFilter = !openFilter"
                        class="px-4 py-2.5 bg-white hover:bg-slate-50 border border-slate-300/45 rounded-xl flex items-center space-x-1.5 text-xs font-extrabold text-slate-700 shadow-xs cursor-pointer active:scale-[0.98] transition-all"
                    >
                        <svg class="w-4 h-4 text-slate-500 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 01-.659 1.591l-5.432 5.432a2.25 2.25 0 00-.659 1.591v2.927a2.25 2.25 0 01-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 00-.659-1.591L3.659 7.409A2.25 2.25 0 013 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0112 3z" />
                        </svg>
                        <span>Filter</span>
                    </button>

                    <!-- Filter Options Dropdown Popover Menu -->
                    <div 
                        x-show="openFilter" 
                        @click.away="openFilter = false"
                        x-transition:enter="transition ease-out duration-100"
                        x-transition:enter-start="transform opacity-0 scale-95"
                        x-transition:enter-end="transform opacity-100 scale-100"
                        x-transition:leave="transition ease-in duration-75"
                        x-transition:leave-start="transform opacity-100 scale-100"
                        x-transition:leave-end="transform opacity-0 scale-95"
                        class="absolute left-0 mt-1.5 w-48 rounded-2xl bg-white shadow-lg border border-gray-100 z-30 py-1.5 overflow-hidden" 
                        style="display: none;"
                    >
                        <div class="px-4 py-1.5 text-[9px] text-slate-400 font-extrabold uppercase tracking-wider border-b border-slate-50">Urutkan Siswa</div>
                        
                        <button 
                            wire:click="$set('sortBy', 'name_asc')" 
                            @click="openFilter = false"
                            class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer flex items-center justify-between {{ $sortBy === 'name_asc' ? 'bg-amber-50/50 text-amber-900' : '' }}"
                        >
                            <span>Nama A - Z</span>
                            @if($sortBy === 'name_asc')
                                <svg class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            @endif
                        </button>
                        
                        <button 
                            wire:click="$set('sortBy', 'name_desc')" 
                            @click="openFilter = false"
                            class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer flex items-center justify-between {{ $sortBy === 'name_desc' ? 'bg-amber-50/50 text-amber-900' : '' }}"
                        >
                            <span>Nama Z - A</span>
                            @if($sortBy === 'name_desc')
                                <svg class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            @endif
                        </button>

                        <button 
                            wire:click="$set('sortBy', 'balance_desc')" 
                            @click="openFilter = false"
                            class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer flex items-center justify-between {{ $sortBy === 'balance_desc' ? 'bg-amber-50/50 text-amber-900' : '' }}"
                        >
                            <span>Saldo Terbanyak</span>
                            @if($sortBy === 'balance_desc')
                                <svg class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            @endif
                        </button>

                        <button 
                            wire:click="$set('sortBy', 'balance_asc')" 
                            @click="openFilter = false"
                            class="w-full text-left px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 text-xs cursor-pointer flex items-center justify-between {{ $sortBy === 'balance_asc' ? 'bg-amber-50/50 text-amber-900' : '' }}"
                        >
                            <span>Saldo Tersedikit</span>
                            @if($sortBy === 'balance_asc')
                                <svg class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            @endif
                        </button>
                    </div>
                </div>

                <!-- Total Count Label (Right side) -->
                <div class="text-xs text-slate-900 font-extrabold uppercase tracking-wider shrink-0 text-right">
                    TOTAL: {{ $students->count() }} SISWA
                </div>
            </div>
        </div>

        <!-- Student Card List (Floating directly on the yellow background) -->
        <div class="space-y-2.5 relative z-10">
            @forelse($students as $student)
                @php
                    $words = explode(' ', $student->name);
                    $initials = count($words) >= 2 
                        ? substr($words[0], 0, 1) . substr($words[1], 0, 1) 
                        : substr($student->name, 0, 2);
                    $initials = strtoupper($initials);
                @endphp
                
                <!-- Individual Student Card (White block with border, matching mockup layout) -->
                <div wire:key="student-{{ $student->id }}" class="bg-white border border-gray-150 rounded-[24px] p-3.5 sm:p-4.5 flex flex-col space-y-4 shadow-xs hover:border-amber-400 hover:shadow-md transition-all duration-300">
                    
                    <!-- Top Row (Avatar, Name/NISN, Balance, Chevron) -->
                    <div class="flex items-center justify-between w-full">
                        
                        <!-- Left: Avatar & Name details -->
                        <div class="flex items-center space-x-4 min-w-0 flex-1">
                            <!-- Initials Avatar (Large circular profile) -->
                            <div class="w-14 h-14 sm:w-18 sm:h-18 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center font-extrabold text-slate-700 text-sm sm:text-xl shrink-0 font-['Outfit'] shadow-xs">
                                {{ $initials }}
                            </div>
 
                            <!-- Name & NISN -->
                            <div class="text-left font-['Outfit'] min-w-0 space-y-0.5">
                                <h3 class="text-sm sm:text-lg md:text-xl font-extrabold text-slate-850 tracking-tight truncate">{{ $student->name }}</h3>
                                <p class="text-xs sm:text-sm text-slate-400 font-semibold">NISN: {{ $student->nisn }}</p>
                            </div>
                        </div>
 
                        <!-- Right: Balance & Chevron Link -->
                        <div class="flex items-center space-x-4 shrink-0 font-['Outfit']">
                            <div class="text-right">
                                <span class="text-[9px] sm:text-xs text-slate-400 font-extrabold uppercase tracking-wider block">Saldo Aktif</span>
                                
                                <!-- Balanced Color logic matching mockup (red for high, green for normal/positive, dark slate for 0) -->
                                @if($student->balance == 0)
                                    <span class="text-xs sm:text-sm md:text-base font-extrabold text-[#0f172a] mt-0.5 block">
                                        Rp 0
                                    </span>
                                @elseif($student->balance >= 100000)
                                    <span class="text-xs sm:text-sm md:text-base font-extrabold text-rose-600 mt-0.5 block">
                                        Rp {{ number_format($student->balance, 0, ',', '.') }}
                                    </span>
                                @else
                                    <span class="text-xs sm:text-sm md:text-base font-extrabold text-emerald-600 mt-0.5 block">
                                        Rp {{ number_format($student->balance, 0, ',', '.') }}
                                    </span>
                                @endif
                            </div>
                            
                            <!-- Light gray chevron right icon -->
                            <div class="text-slate-400">
                                <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                                </svg>
                            </div>
                        </div>
 
                    </div>
 
                    <!-- Bottom Row (Action Buttons - Aligned to the right edge) -->
                    <div class="flex items-center justify-end w-full">
                         <!-- Deposit Button (Yellow - Client side Alpine triggers zero lag) -->
                         <button 
                             @click="selectedId = {{ $student->id }}; selectedName = '{{ addslashes($student->name) }}'; depositAmount = ''; formattedAmount = ''; openDeposit = true"
                             class="px-4 py-2 sm:px-5 sm:py-2.5 bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold rounded-xl flex items-center space-x-1.5 text-xs sm:text-sm transition-all active:scale-[0.98] cursor-pointer shadow-xs"
                         >
                            <svg class="w-4 h-4 text-slate-900" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" />
                                <path fill-rule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM16 13a1 1 0 11-2 0 1 1 0 012 0z" clip-rule="evenodd" />
                            </svg>
                            <span>Setor</span>
                        </button>
                    </div>
 
                </div>
            @empty
                <div class="bg-white border border-gray-150 rounded-3xl p-8 text-center text-slate-400 font-medium italic shadow-xs font-['Outfit']">
                    Tidak ada data siswa ditemukan.
                </div>
            @endforelse
        </div>
        
        <!-- Pagination Controls -->
        @if($students->hasPages())
            <div class="mt-4 flex items-center justify-between font-['Outfit'] text-xs font-semibold px-2 relative z-10">
                <button 
                    wire:click="previousPage" 
                    @if($students->onFirstPage()) disabled @endif
                    class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95 shadow-3xs"
                >
                    Sebelumnya
                </button>
                
                <span class="text-slate-800 font-bold bg-white/70 backdrop-blur-xs px-3 py-1.5 rounded-full border border-white/20 shadow-3xs">
                    Halaman {{ $students->currentPage() }} dari {{ $students->lastPage() }}
                </span>
                
                <button 
                    wire:click="nextPage" 
                    @if(!$students->hasMorePages()) disabled @endif
                    class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95 shadow-3xs"
                >
                    Selanjutnya
                </button>
            </div>
        @endif
    @endif

<!-- Deposit Overlay Modal (Alpine-controlled for zero-lag responsiveness) -->
<div 
    x-show="openDeposit" 
    x-transition
    class="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4"
    style="display: none;"
>
    <div class="bg-white rounded-3xl p-6 shadow-xl max-w-sm w-full border border-slate-100 relative space-y-4" @click.away="openDeposit = false">
        <div class="flex items-center justify-between">
            <h3 class="text-sm font-extrabold text-slate-800 tracking-tight font-['Outfit']">Setor Tunai Tabungan</h3>
            <button @click="openDeposit = false" class="text-slate-400 hover:text-slate-600 focus:outline-hidden cursor-pointer">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <div class="bg-amber-50/50 border border-amber-100 p-3 rounded-xl text-left">
            <span class="text-[9px] text-amber-800/80 font-bold uppercase tracking-wider block">Nama Siswa</span>
            <span class="text-xs font-bold text-slate-700 block mt-0.5" x-text="selectedName"></span>
        </div>

        <form @submit.prevent="$wire.simpanSetoran(selectedId, depositAmount).then(res => { if(res === true) { openDeposit = false; } })" class="space-y-4 font-sans">
            <div class="space-y-1.5">
                <label for="depositAmount" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Nominal Setoran (Rp)</label>
                <input 
                    type="text" 
                    id="depositAmount"
                    x-model="formattedAmount"
                    @input="updateAmount($event.target.value)"
                    class="w-full px-4 py-3 border @error('depositAmount') border-rose-500 focus:border-rose-500 focus:ring-rose-500/10 @else border-slate-200 focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 @enderror rounded-xl text-base md:text-sm placeholder-slate-400 focus:outline-hidden bg-slate-50/40 font-bold"
                    placeholder="Contoh: 50.000"
                    required
                >
                @error('depositAmount') 
                    <span class="text-[10px] text-rose-500 font-bold block">{{ $message }}</span> 
                @enderror
            </div>

            <button 
                type="submit"
                class="w-full py-3 bg-[#ffd554] hover:bg-[#e5bf43] text-slate-900 font-extrabold rounded-xl transition-all active:scale-[0.98] cursor-pointer shadow-md text-xs"
            >
                Simpan Setoran
            </button>
        </form>
    </div>
</div>
</div>
