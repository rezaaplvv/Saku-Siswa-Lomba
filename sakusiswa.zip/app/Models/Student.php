<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $fillable = [
        'nisn',
        'name',
        'class_name',
        'balance',
        'parent_username',
        'parent_password',
        'saving_target',
        'parent_pin',
        'must_change_password',
    ];
}