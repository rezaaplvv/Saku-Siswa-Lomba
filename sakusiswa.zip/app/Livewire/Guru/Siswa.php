<?php

namespace App\Livewire\Guru;

use App\Models\Student;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Livewire\WithPagination;

class Siswa extends Component
{
    use WithPagination;

    public ?string $className = null;
    public string $search = '';
    public string $sortBy = 'name_asc';
    
    // Properties for deposit modal state
    public ?int $selectedStudentId = null;
    public string $selectedStudentName = '';
    public string $depositAmount = '';

    protected $queryString = [
        'search' => ['except' => ''],
        'sortBy' => ['except' => 'name_asc']
    ];

    public function mount()
    {
        if (Auth::user()->role !== 'guru') {
            abort(403, 'Akses ditolak.');
        }
        $this->className = Auth::user()->class_name;
    }

    public function selectStudentForDeposit($studentId, $studentName)
    {
        $this->selectedStudentId = $studentId;
        $this->selectedStudentName = $studentName;
        $this->depositAmount = '';
        $this->resetValidation();
    }

    public function closeDepositModal()
    {
        $this->selectedStudentId = null;
        $this->selectedStudentName = '';
        $this->depositAmount = '';
        $this->resetValidation();
    }

    public function simpanSetoran($studentId = null, $amount = null)
    {
        if (!$this->className) {
            session()->flash('error', 'Anda tidak terdaftar sebagai wali kelas.');
            return false;
        }

        if ($studentId !== null) {
            $this->selectedStudentId = $studentId;
        }
        if ($amount !== null) {
            $this->depositAmount = $amount;
        }

        $this->validate([
            'depositAmount' => 'required|integer|min:1000|max:10000000'
        ], [
            'depositAmount.required' => 'Nominal wajib diisi.',
            'depositAmount.integer' => 'Nominal harus berupa bilangan bulat.',
            'depositAmount.min' => 'Nominal setoran minimal Rp 1.000.',
            'depositAmount.max' => 'Nominal setoran maksimal Rp 10.000.000 sekali transaksi.'
        ]);

        $success = false;

        DB::transaction(function () use (&$success) {
            $student = Student::where('id', $this->selectedStudentId)
                ->where('class_name', $this->className)
                ->lockForUpdate()
                ->first();

            if ($student) {
                // Record transaction
                Transaction::create([
                    'student_id' => $student->id,
                    'user_id' => Auth::id(),
                    'type' => 'deposit',
                    'amount' => $this->depositAmount,
                    'status' => 'approved',
                    'notes' => 'Setoran tunai oleh Wali Kelas'
                ]);

                // Increment balance
                $student->increment('balance', $this->depositAmount);
                
                session()->flash('success', 'Setoran sebesar Rp ' . number_format($this->depositAmount, 0, ',', '.') . ' untuk ' . $student->name . ' berhasil disimpan.');
                $success = true;
            } else {
                session()->flash('error', 'Siswa tidak ditemukan atau bukan bagian dari kelas Anda.');
            }
        });

        $this->closeDepositModal();
        return $success;
    }
    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function render()
    {
        if (!$this->className) {
            return view('livewire.guru.siswa', [
                'students' => collect()
            ])->layout('layouts.dashboard', ['title' => 'Kelola Siswa']);
        }

        $query = Student::where('class_name', $this->className)
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                      ->orWhere('nisn', 'like', '%' . $this->search . '%');
                });
            });

        if ($this->sortBy === 'name_asc') {
            $query->orderBy('name', 'asc');
        } elseif ($this->sortBy === 'name_desc') {
            $query->orderBy('name', 'desc');
        } elseif ($this->sortBy === 'balance_desc') {
            $query->orderBy('balance', 'desc');
        } elseif ($this->sortBy === 'balance_asc') {
            $query->orderBy('balance', 'asc');
        }

        $students = $query->paginate(10);

        return view('livewire.guru.siswa', [
            'students' => $students
        ])->layout('layouts.dashboard', ['title' => 'Kelola Siswa']);
    }
}
