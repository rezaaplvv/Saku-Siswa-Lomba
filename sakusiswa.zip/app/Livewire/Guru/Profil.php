<?php

namespace App\Livewire\Guru;

use App\Models\Student;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class Profil extends Component
{
    public ?string $className = null;

    // Form fields for changing password
    public string $current_password = '';
    public string $new_password = '';
    public string $new_password_confirmation = '';

    public function mount()
    {
        if (Auth::user()->role !== 'guru') {
            abort(403, 'Akses ditolak.');
        }
        $this->className = Auth::user()->class_name;
    }

    public function changePassword()
    {
        $user = Auth::user();
        $dbUser = User::findOrFail($user->id);

        $this->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|confirmed',
        ], [
            'current_password.required' => 'Password saat ini wajib diisi.',
            'new_password.required' => 'Password baru wajib diisi.',
            'new_password.min' => 'Password baru minimal terdiri dari 6 karakter.',
            'new_password.confirmed' => 'Konfirmasi password baru tidak cocok.',
        ]);

        if (!Hash::check($this->current_password, $dbUser->password)) {
            $this->addError('current_password', 'Password saat ini salah.');
            return;
        }

        $dbUser->password = Hash::make($this->new_password);
        $dbUser->save();

        $this->reset(['current_password', 'new_password', 'new_password_confirmation']);
        $this->dispatch('close-modal');

        session()->flash('success', 'Password login berhasil diperbarui.');
    }

    public function render()
    {
        $user = Auth::user();
        $siswaCount = 0;

        if ($this->className) {
            $siswaCount = Student::where('class_name', $this->className)->count();
        }

        return view('livewire.guru.profil', [
            'user' => $user,
            'siswaCount' => $siswaCount,
        ])->layout('layouts.dashboard', ['title' => 'Profil - SakuSiswa']);
    }
}
