<?php

namespace App\Livewire\Admin;

use App\Models\Student;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithPagination;

class Siswa extends Component
{
    use WithPagination;

    public string $search = '';
    public string $classFilter = '';

    // Form fields
    public $studentId = null;
    public string $nisn = '';
    public string $name = '';
    public string $class_name = '';
    public float $balance = 0.00;
    public float $saving_target = 500000.00;

    public bool $isFormOpen = false;

    public function mount()
    {
        if (Auth::user()->role !== 'admin') {
            abort(403, 'Akses ditolak.');
        }
    }

    public function openForm($id = null)
    {
        $this->resetErrorBag();
        $this->studentId = $id;

        if ($id) {
            $student = Student::findOrFail($id);
            $this->nisn = $student->nisn;
            $this->name = $student->name;
            $this->class_name = $student->class_name;
            $this->balance = (float) $student->balance;
            $this->saving_target = (float) $student->saving_target;
        } else {
            $this->nisn = '';
            $this->name = '';
            $this->class_name = '';
            $this->balance = 0.00;
            $this->saving_target = 500000.00;
        }

        $this->isFormOpen = true;
    }

    public function closeForm()
    {
        $this->isFormOpen = false;
        $this->reset(['studentId', 'nisn', 'name', 'class_name', 'balance', 'saving_target']);
        $this->resetErrorBag();
    }

    public function saveStudent()
    {
        // Remove any accidental spaces or non-digit characters (e.g. from copy-paste)
        $this->nisn = preg_replace('/\D/', '', $this->nisn);

        $rules = [
            'nisn' => [
                'required',
                'numeric',
                'digits:10',
                Rule::unique('students', 'nisn')->ignore($this->studentId),
            ],
            'name' => 'required|min:3',
            'class_name' => 'required',
            'balance' => 'required|numeric|min:0',
            'saving_target' => 'required|numeric|min:0',
        ];

        $this->validate($rules, [
            'nisn.required' => 'NISN wajib diisi.',
            'nisn.numeric' => 'NISN harus berupa angka.',
            'nisn.digits' => 'NISN harus tepat 10 digit.',
            'nisn.unique' => 'NISN sudah terdaftar.',
            'name.required' => 'Nama siswa wajib diisi.',
            'name.min' => 'Nama minimal terdiri dari 3 karakter.',
            'class_name.required' => 'Kelas wajib diampu.',
            'balance.required' => 'Saldo awal wajib ditentukan.',
            'balance.min' => 'Saldo awal tidak boleh negatif.',
            'saving_target.required' => 'Target tabungan wajib ditentukan.',
            'saving_target.min' => 'Target tabungan tidak boleh negatif.',
        ]);

        if ($this->studentId) {
            // Update
            $student = Student::findOrFail($this->studentId);
            $oldNisn = $student->nisn;

            $updateData = [
                'nisn' => $this->nisn,
                'name' => $this->name,
                'class_name' => $this->class_name,
                'saving_target' => $this->saving_target,
                'parent_username' => 'ortu_' . $this->nisn,
            ];

            // Issue 4: If NISN changes, regenerate parent password using new NISN
            if ($oldNisn !== $this->nisn) {
                $updateData['parent_password'] = Hash::make($this->nisn);
                $updateData['must_change_password'] = true;
            }

            $student->update($updateData);
            session()->flash('success', 'Data siswa ' . $this->name . ' berhasil diperbarui.');
        } else {
            // Create
            $student = Student::create([
                'nisn' => $this->nisn,
                'name' => $this->name,
                'class_name' => $this->class_name,
                'balance' => $this->balance,
                'saving_target' => $this->saving_target,
                'parent_username' => 'ortu_' . $this->nisn,
                'parent_password' => Hash::make($this->nisn),
                'must_change_password' => false,
            ]);

            // Issue 1: Log initial deposit transaction if starting balance > 0
            if ($this->balance > 0) {
                Transaction::create([
                    'student_id' => $student->id,
                    'user_id' => Auth::id(),
                    'type' => 'deposit',
                    'amount' => $this->balance,
                    'status' => 'approved',
                    'notes' => 'Setoran Awal Tabungan Baru',
                ]);
            }

            session()->flash('success', 'Siswa baru ' . $this->name . ' beserta akun orang tua berhasil ditambahkan.');
        }

        $this->closeForm();
    }

    public function deleteStudent($id)
    {
        $student = Student::findOrFail($id);
        $name = $student->name;
        
        $student->delete();
        session()->flash('success', 'Data siswa ' . $name . ' berhasil dihapus.');
    }

    public bool $isClassroomModalOpen = false;
    public string $newClassroomName = '';

    public function openClassroomModal()
    {
        $this->newClassroomName = '';
        $this->isClassroomModalOpen = true;
        $this->resetErrorBag();
    }

    public function closeClassroomModal()
    {
        $this->isClassroomModalOpen = false;
    }

    public function addClassroom()
    {
        $this->validate([
            'newClassroomName' => 'required|min:2|max:10|unique:classrooms,name'
        ], [
            'newClassroomName.required' => 'Nama kelas wajib diisi.',
            'newClassroomName.min' => 'Minimal 2 karakter.',
            'newClassroomName.max' => 'Maksimal 10 karakter.',
            'newClassroomName.unique' => 'Kelas sudah terdaftar.'
        ]);

        \App\Models\Classroom::create([
            'name' => strtoupper(trim($this->newClassroomName))
        ]);

        $this->newClassroomName = '';
        session()->flash('class_success', 'Kelas baru berhasil ditambahkan.');
    }

    public function deleteClassroom($id)
    {
        $classroom = \App\Models\Classroom::findOrFail($id);
        
        $hasStudents = \App\Models\Student::where('class_name', $classroom->name)->exists();
        $hasTeachers = \App\Models\User::where('class_name', $classroom->name)->exists();

        if ($hasStudents || $hasTeachers) {
            session()->flash('class_error', 'Kelas tidak bisa dihapus karena sedang digunakan.');
            return;
        }

        $classroom->delete();
        session()->flash('class_success', 'Kelas berhasil dihapus.');
    }

    public function resetPasswordOrangTua($studentId)
    {
        $student = Student::findOrFail($studentId);
        $student->update([
            'parent_password' => Hash::make($student->nisn),
            'must_change_password' => true,
        ]);
        session()->flash('success', 'Password Orang Tua ' . $student->name . ' berhasil direset ke NISN (' . $student->nisn . ') dan wajib diubah saat login berikutnya.');
    }

    public function resetPinOrangTua($studentId)
    {
        $student = Student::findOrFail($studentId);
        $student->update([
            'parent_pin' => null,
        ]);
        session()->flash('success', 'PIN Orang Tua ' . $student->name . ' berhasil direset ke NULL.');
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingClassFilter()
    {
        $this->resetPage();
    }

    public function render()
    {
        $students = Student::query()
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                      ->orWhere('nisn', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->classFilter, function ($query) {
                $query->where('class_name', $this->classFilter);
            })
            ->paginate(10);

        return view('livewire.admin.siswa', [
            'students' => $students,
            'classrooms' => \App\Models\Classroom::orderBy('name')->get(),
            'availableClasses' => \App\Models\Classroom::orderBy('name')->pluck('name')->toArray()
        ])->layout('layouts.dashboard', ['title' => 'Kelola Siswa - SakuSiswa']);
    }
}
