<?php

namespace App\Livewire\Auth;

use App\Models\Student;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class Login extends Component
{
    public $loginType = 'user'; // 'user' (Parent/Guru) or 'admin'
    
    // Form fields
    public $username_or_email = '';
    public $password = '';
    public $remember = false;

    // Validation rules
    protected function rules()
    {
        if ($this->loginType === 'admin') {
            return [
                'username_or_email' => 'required|email',
                'password' => 'required|min:6',
            ];
        }

        return [
            'username_or_email' => 'required',
            'password' => 'required|min:6',
        ];
    }

    protected $messages = [
        'username_or_email.required' => 'Email atau Username wajib diisi.',
        'username_or_email.email' => 'Format email tidak valid.',
        'password.required' => 'Password wajib diisi.',
        'password.min' => 'Password minimal terdiri dari 6 karakter.',
    ];

    public function selectRole($type)
    {
        $this->loginType = $type;
        $this->resetValidation();
        $this->username_or_email = '';
        $this->password = '';
    }

    public function login()
    {
        $this->validate();

        if ($this->loginType === 'admin') {
            // Admin login
            if (Auth::attempt(['email' => $this->username_or_email, 'password' => $this->password, 'role' => 'admin'], $this->remember)) {
                // Clear any leftover parent session data
                session()->forget(['parent_logged_in', 'student_id', 'parent_student_id']);
                session()->regenerate();
                return redirect()->intended('/admin/dashboard');
            }

            $this->addError('username_or_email', 'Kredensial Administrator tidak cocok.');
        } else {
            // Main gate: can be Guru (Email) or Parent (Username)
            if (filter_var($this->username_or_email, FILTER_VALIDATE_EMAIL)) {
                // Email -> Guru
                if (Auth::attempt(['email' => $this->username_or_email, 'password' => $this->password], $this->remember)) {
                    // Clear any leftover parent session data
                    session()->forget(['parent_logged_in', 'student_id', 'parent_student_id']);
                    $role = Auth::user()->role;
                    session()->regenerate();
                    if ($role === 'admin') {
                        return redirect()->intended('/admin/dashboard');
                    }
                    return redirect()->intended('/guru/dashboard');
                }
                
                $this->addError('username_or_email', 'Email atau password guru tidak cocok.');
            } else {
                // NISN -> Parent (Orang Tua)
                $student = Student::where('nisn', $this->username_or_email)->first();

                if ($student && Hash::check($this->password, $student->parent_password)) {
                    // Logout any active Auth (Admin/Guru) guard session to avoid clashing layouts
                    Auth::logout();
                    
                    session()->regenerate();
                    session([
                        'parent_logged_in' => true,
                        'student_id' => $student->id,
                        'parent_student_id' => $student->id,
                        'parent_password_hash' => $student->parent_password
                    ]);
                    
                    return redirect()->intended('/parent/dashboard');
                }

                $this->addError('username_or_email', 'NISN atau password orang tua salah.');
            }
        }
    }

    public function render()
    {
        return view('livewire.auth.login')
            ->layout('layouts.app', ['title' => 'Login - SakuSiswa']);
    }
}
