<?php
namespace Database\Seeders;

use App\Models\User;
use App\Models\Student;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Membuat Akun Admin Utama
        User::create([
            'name' => 'Administrator Sekolah',
            'email' => 'admin@sekolah.com',
            'password' => Hash::make('password123'),
            'role' => 'admin',
        ]);

        // 2. Membuat Akun Guru Kelas
        User::create([
            'name' => 'Siti Aminah, S.Pd.',
            'email' => 'guru@sekolah.com',
            'password' => Hash::make('password123'),
            'role' => 'guru',
            'class_name' => '1-A',
        ]);

        // 3. Membuat Akun Data Siswa + Akun Akses Orang Tua (Wali Murid)
        Student::create([
            'nisn' => '0123456789',
            'name' => 'Ahmad Rafif',
            'class_name' => '1-A',
            'balance' => 150000.00, // Saldo awal simulasi Rp150.000
            'parent_username' => 'ortu_rafif',
            'parent_password' => Hash::make('rafif123'),
        ]);

        Student::create([
            'nisn' => '0123456790',
            'name' => 'Siti Aisyah',
            'class_name' => '1-A',
            'balance' => 0.00, // Saldo awal kosong
            'parent_username' => 'ortu_aisyah',
            'parent_password' => Hash::make('aisyah123'),
        ]);
    }
}