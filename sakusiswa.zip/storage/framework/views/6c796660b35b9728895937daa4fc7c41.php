<div class="h-screen w-screen flex flex-col md:flex-row overflow-hidden font-sans relative">
    
    <!-- Premium Google Fonts Import -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- ======================================================== -->
    <!-- LEFT HALF: Brand Title & Mascot (Desktop Only - Yellow)  -->
    <!-- ======================================================== -->
    <div class="hidden md:flex md:w-1/2 h-full bg-[#ffd554] flex-col justify-between p-12 relative overflow-hidden text-left items-start">
        <!-- Floating white gradient circles -->
        <div class="absolute -top-10 -right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none z-0"></div>
        <div class="absolute -bottom-10 -left-10 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none z-0"></div>
        
        <!-- Top Right Dot Grid Pattern -->
        <div class="absolute top-12 right-12 text-amber-600/20 pointer-events-none z-0">
            <svg width="48" height="32" viewBox="0 0 48 32" fill="currentColor">
                <circle cx="4" cy="4" r="2" />
                <circle cx="16" cy="4" r="2" />
                <circle cx="28" cy="4" r="2" />
                <circle cx="40" cy="4" r="2" />
                <circle cx="4" cy="16" r="2" />
                <circle cx="16" cy="16" r="2" />
                <circle cx="28" cy="16" r="2" />
                <circle cx="40" cy="16" r="2" />
                <circle cx="4" cy="28" r="2" />
                <circle cx="16" cy="28" r="2" />
                <circle cx="28" cy="28" r="2" />
                <circle cx="40" cy="28" r="2" />
            </svg>
        </div>

        <!-- 1. TOP HEADER: Logo & SakuSiswa Branding -->
        <div class="flex items-center space-x-3.5 relative z-10">
            <div class="w-11 h-11 rounded-2xl bg-white/90 flex items-center justify-center text-amber-600 shrink-0 shadow-xs border border-white/20">
                <img src="/assets/logosekolah.png" alt="Mascot Mini" class="w-7 h-7 object-contain">
            </div>
            <h2 class="text-2xl lg:text-3xl font-extrabold text-slate-800 tracking-tight font-['Outfit']">
                Saku<span class="text-amber-800">Siswa</span>
            </h2>
        </div>

        <!-- 2. MIDDLE CONTENT: Headline & Description -->
        <div class="space-y-4 max-w-sm relative z-10 mt-8">
            <!-- Headline -->
            <h1 class="text-3xl lg:text-4xl font-extrabold text-slate-800 leading-tight font-['Outfit'] tracking-tight">
                Menabung hari ini,<br>
                <span class="text-amber-800">masa depan<br>lebih cerah.</span>
            </h1>
        </div>

        <!-- 3. BOTTOM CONTENT: Large Mascot Image centered at the bottom -->
        <div class="w-full flex-1 flex items-end justify-center mt-6 relative z-10 pointer-events-none">
            <img src="/assets/maskot.png" alt="Mascot" class="max-h-[50vh] lg:max-h-[58vh] object-contain filter drop-shadow-[0_20px_40px_rgba(0,0,0,0.08)] hover:scale-103 transition-transform duration-500">
        </div>
    </div>

    <!-- ======================================================== -->
    <!-- RIGHT HALF: Login Form (Solid Yellow Mobile background)   -->
    <!-- ======================================================== -->
    <div class="w-full md:w-1/2 h-full bg-[#f4f7f6] md:bg-white flex flex-col justify-center items-center p-4 sm:p-6 md:p-12 relative max-md:bg-[#ffd554]">
        
        <!-- Mobile-only background decorative shapes -->
        <div class="block md:hidden absolute -top-40 -left-40 w-[600px] h-[600px] bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="block md:hidden absolute bottom-[-150px] right-[-150px] w-[600px] h-[600px] bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <!-- Mobile-only Top Right Dot Matrix decoration -->
        <div class="block md:hidden absolute top-8 right-6 text-white/30 pointer-events-none">
            <svg width="24" height="24" viewBox="0 0 32 32" fill="currentColor">
                <circle cx="4" cy="4" r="2" />
                <circle cx="14" cy="4" r="2" />
                <circle cx="24" cy="4" r="2" />
                <circle cx="4" cy="14" r="2" />
                <circle cx="14" cy="14" r="2" />
                <circle cx="24" cy="14" r="2" />
                <circle cx="4" cy="24" r="2" />
                <circle cx="14" cy="24" r="2" />
                <circle cx="24" cy="24" r="2" />
            </svg>
        </div>

        <!-- Mobile-only Mascot Header -->
        <div class="flex md:hidden justify-center mb-3 relative z-10">
            <img src="/assets/maskot.png" class="h-[30vh] max-h-[200px] object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.12)]" alt="Maskot">
        </div>

        <!-- White Card Wrapper with Rotated Accent Layers -->
        <div class="w-full max-w-md relative">
            
            <!-- Actual White Card Container (No borders, shadow, or padding on desktop) -->
            <div class="w-full bg-white rounded-3xl p-4 sm:p-6 shadow-2xl border border-slate-100/80 md:shadow-none md:border-none md:p-0 md:bg-transparent relative z-10">
                <div class="space-y-3.5 md:space-y-5">
                    
                    <!-- Logo and Title row (Unified for Mobile view) -->
                    <div class="flex md:hidden items-center space-x-3 pb-2.5 border-b border-slate-100 mb-2">
                        <div class="bg-amber-50 p-2 rounded-xl border border-amber-200/50 shadow-xs flex-shrink-0">
                            <img src="/assets/logosekolah.png" alt="Logo" class="w-8 h-8 object-contain">
                        </div>
                        <div class="text-left space-y-0.5 font-['Plus_Jakarta_Sans']">
                            <h2 class="text-lg font-extrabold text-slate-800 tracking-tight font-['Outfit']">
                                <?php echo $loginType === 'admin' ? 'Saku<span class="text-amber-700">Admin</span>' : 'Saku<span class="text-amber-700">Siswa</span>'; ?>

                            </h2>
                            <p class="text-[10px] text-slate-500 font-light leading-relaxed">
                                <?php echo $loginType === 'admin' ? 'Akses khusus untuk <span class="text-amber-700 font-medium">administrator</span> pengelola.' : 'Kelola uang saku dan tabungan siswa dengan mudah.'; ?>

                            </p>
                        </div>
                    </div>

                    <!-- Desktop-only Card Header (Rebranded to SakuSiswa) -->
                    <div class="hidden md:block text-center space-y-3 font-['Outfit']">
                        <img src="/assets/logosekolah.png" alt="Logo Sekolah" class="w-16 h-16 mx-auto object-contain hover:rotate-3 transition-transform duration-300">
                        <div class="space-y-1">
                            <h2 class="text-2xl lg:text-3xl font-extrabold text-slate-800 tracking-tight font-['Outfit']">
                                <?php echo $loginType === 'admin' ? 'Saku<span class="text-amber-700">Admin</span>' : 'Saku<span class="text-amber-700">Siswa</span>'; ?>

                            </h2>
                            <p class="text-xs text-slate-500 font-light tracking-wide leading-relaxed">
                                <?php echo $loginType === 'admin' ? 'Akses masuk portal <span class="text-amber-700 font-semibold">Administrator Utama</span> SDN Cigowong 01.' : 'Masukkan kredensial Anda untuk memantau uang saku dan saldo <span class="text-amber-700 font-semibold">secara berkala</span>.'; ?>

                            </p>
                        </div>
                    </div>

                    <!-- Input Form -->
                    <form wire:submit.prevent="login" class="space-y-3.5 md:space-y-5 font-['Plus_Jakarta_Sans']">
                        <!-- Input: Email / Username -->
                        <div class="space-y-1.5">
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-amber-600">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loginType === 'admin'): ?>
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z"></path>
                                        <?php else: ?>
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75"></path>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </svg>
                                </span>
                                <input 
                                    type="<?php echo e($loginType === 'admin' ? 'email' : 'text'); ?>" 
                                    id="username_or_email" 
                                    wire:model="username_or_email"
                                    class="w-full pl-11 pr-4 py-3.5 rounded-2xl border border-slate-200 text-base md:text-sm placeholder-slate-400/80 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40 hover:bg-amber-50/30 shadow-xs transition-all duration-300"
                                    placeholder="<?php echo e($loginType === 'admin' ? 'Email Administrator' : 'Email Guru atau NISN Siswa'); ?>"
                                    autocomplete="username"
                                >
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['username_or_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-rose-500 font-medium"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <!-- Input: Password -->
                        <div class="space-y-1.5" x-data="{ showPass: false }">
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-amber-600">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                    </svg>
                                </span>
                                <input 
                                    :type="showPass ? 'text' : 'password'" 
                                    id="password" 
                                    wire:model="password"
                                    class="w-full pl-11 pr-12 py-3.5 rounded-2xl border border-slate-200 text-base md:text-sm placeholder-slate-400/80 focus:outline-hidden focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 bg-slate-50/40 hover:bg-amber-50/30 shadow-xs transition-all duration-300"
                                    placeholder="Password"
                                    autocomplete="current-password"
                                >
                                <button 
                                    type="button"
                                    @click="showPass = !showPass"
                                    class="absolute inset-y-0 right-0 pr-4 flex items-center text-amber-600 hover:text-amber-700 focus:outline-hidden cursor-pointer"
                                >
                                    <!-- Eye Icon (Open) -->
                                    <svg x-show="!showPass" class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.43 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                                    </svg>
                                    <!-- Eye Icon (Closed) -->
                                    <svg x-show="showPass" class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="display: none;">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.815 7.815L21 21m-3.957-3.957-1.4 1.4m-1.432-1.432a4.969 4.969 0 0 1-3.037.404M15 12a3 3 0 0 1-3 3m0 0a3.003 3.003 0 0 1-2.247-4.293M12 9a3 3 0 0 1 3 3"></path>
                                    </svg>
                                </button>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-rose-500 font-medium"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <!-- Checkbox and Forgot Password -->
                        <div class="flex items-center justify-between text-xs md:text-sm select-none">
                            <label class="flex items-center text-slate-500 cursor-pointer">
                                <input 
                                    type="checkbox" 
                                    wire:model="remember"
                                    class="h-4.5 w-4.5 rounded-sm border-slate-300 text-amber-600 focus:ring-amber-500 transition-all duration-150 mr-2 cursor-pointer"
                                >
                                <span>Ingat saya</span>
                            </label>
                            <a href="#" class="text-amber-600 hover:text-amber-700 hover:underline font-semibold transition-colors duration-150">Lupa Password?</a>
                        </div>

                        <!-- Yellow Submit Button -->
                        <button 
                            type="submit" 
                            wire:loading.attr="disabled"
                            class="w-full h-13 bg-[#ffd554] hover:bg-[#e5bf43] text-slate-900 text-base font-extrabold rounded-xl shadow-lg shadow-amber-500/10 active:scale-[0.98] transition-all duration-300 flex items-center justify-center cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                        >
                            <span wire:loading.remove wire:target="login" class="tracking-wide">Masuk</span>
                            <span wire:loading wire:target="login">
                                <span class="flex items-center justify-center space-x-2">
                                    <svg class="animate-spin h-5 w-5 text-slate-900" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle class="opacity-20" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                        <path class="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <span class="tracking-wide font-extrabold text-slate-900">Memproses...</span>
                                </span>
                            </span>
                        </button>
                    </form>

                    <!-- Divider -->
                    <div class="flex items-center my-3 font-['Outfit']">
                        <div class="flex-grow border-t border-slate-100"></div>
                        <span class="mx-4 text-xs font-semibold text-slate-400">atau</span>
                        <div class="flex-grow border-t border-slate-100"></div>
                    </div>

                    <!-- Alternate Role Gate Button -->
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loginType === 'user'): ?>
                        <button 
                            type="button" 
                            wire:click="selectRole('admin')"
                            class="w-full py-3.5 bg-amber-50 hover:bg-amber-100/60 border border-amber-200/50 hover:border-amber-300 rounded-xl flex items-center justify-center space-x-2.5 text-sm md:text-base font-bold text-amber-800 active:scale-[0.98] transition-all duration-300 cursor-pointer shadow-xs hover:shadow-md font-['Outfit']"
                        >
                            <svg class="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632z"></path>
                            </svg>
                            <span>Masuk sebagai Admin</span>
                            <svg class="w-4 h-4 text-amber-700" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"></path>
                            </svg>
                        </button>
                    <?php else: ?>
                        <button 
                            type="button" 
                            wire:click="selectRole('user')"
                            class="w-full py-3.5 bg-amber-50 hover:bg-amber-100/60 border border-amber-200/50 hover:border-amber-300 rounded-xl flex items-center justify-center space-x-2.5 text-sm md:text-base font-bold text-amber-800 active:scale-[0.98] transition-all duration-300 cursor-pointer shadow-xs hover:shadow-md font-['Outfit']"
                        >
                            <svg class="w-4.5 h-4.5 text-amber-700 transform rotate-180" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"></path>
                            </svg>
                            <span>Masuk sebagai Wali / Guru</span>
                            <svg class="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                            </svg>
                        </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <!-- Center Register Link under Switcher Button -->
                    <div class="text-center pt-2 text-xs text-slate-500 font-medium">
                        Belum punya akun? <a href="#" class="text-amber-600 font-bold hover:underline">Hubungi Admin</a>
                    </div>
                </div>
            </div>

        </div>

        <!-- ======================================================== -->
        <!-- BOTTOM FOOTER                                            -->
        <!-- ======================================================== -->


        <!-- Mobile Footer -->
        <div class="w-full mt-6 pb-6 md:hidden text-xs text-slate-700 text-center relative z-10 font-['Outfit']">
            &copy; 2026 SakuSiswa. All rights reserved.
        </div>

    </div>

    <!-- ======================================================== -->
    <!-- MOBILE BOTTOM CORNER DECORATIVE LEAVES (Soft amber)      -->
    <!-- ======================================================== -->
    <!-- Bottom Left Leaves -->
    <div class="block md:hidden absolute bottom-0 left-0 w-24 h-24 text-amber-800/10 pointer-events-none z-0">
        <svg viewBox="0 0 100 100" fill="currentColor" class="w-full h-full">
            <path d="M0,100 C15,85 30,85 35,70 C40,55 35,40 30,30 C45,45 50,70 35,85 C28,92 14,96 0,100 Z" />
            <path d="M0,100 C20,92 35,80 35,65 C35,50 25,40 18,30 C30,45 42,70 28,85 C18,92 8,96 0,100 Z" />
        </svg>
    </div>
    <!-- Bottom Right Leaves -->
    <div class="block md:hidden absolute bottom-0 right-0 w-24 h-24 text-amber-800/10 pointer-events-none z-0">
        <svg viewBox="0 0 100 100" fill="currentColor" class="w-full h-full transform scale-x-[-1]">
            <path d="M0,100 C15,85 30,85 35,70 C40,55 35,40 30,30 C45,45 50,70 35,85 C28,92 14,96 0,100 Z" />
            <path d="M0,100 C20,92 35,80 35,65 C35,50 25,40 18,30 C30,45 42,70 28,85 C18,92 8,96 0,100 Z" />
        </svg>
    </div>

</div>
<?php /**PATH C:\Users\reza\tabungan-sekolah\resources\views/livewire/auth/login.blade.php ENDPATH**/ ?>